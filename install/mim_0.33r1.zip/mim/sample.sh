#!/bin/sh




echo "
&INPUT
  INPUT_TYPE           = 'general',
  INPUT_U_FILENAME     = 'input-sample/u200801.dr' ,
  INPUT_V_FILENAME     = 'input-sample/v200801.dr' ,
  INPUT_T_FILENAME     = 'input-sample/t200801.dr' ,
  INPUT_PS_FILENAME    = 'input-sample/ps200801.dr' ,
  INPUT_Z_FILENAME     = 'input-sample/z200801.dr' ,
  INPUT_OMEGA_FILENAME = 'input-sample/omega200801.dr' ,
  INPUT_TOPO_FILENAME  = 'input-sample/hgs.dr' ,
  INPUT_Q_FILENAME     = '' ,
/

&INPUT_UNIT
  INPUT_UNIT_PS = 'Pa',
  INPUT_UNIT_TOPO = 'm',
/

&INPUT_UNDEF
  INPUT_UNDEF_DEFAULT = -9.99e+33, 
/

&INPUT_ENDIAN
  INPUT_ENDIAN_DEFAULT = 'little',
/

&INPUT_XDEF
  INPUT_XDEF_NUM = 144,
/

&INPUT_YDEF
  INPUT_YDEF_TYPE  = 'linear',
  INPUT_YDEF_NUM   = 73,
  INPUT_YDEF_SOUTH = -90,
  INPUT_YDEF_NORTH = 90,
  INPUT_YDEF_YREV_DEFAULT = 1, 
/

&INPUT_ZDEF
  INPUT_ZDEF_NUM = 17 ,
  INPUT_ZDEF_NUM_OMEGA = 12 ,
  INPUT_ZDEF_LEVEL  =  
       10.00,   20.00,   30.00,  50.00,  70.00,
      100.00,  150.00,  200.00, 250.00, 300.00,
      400.00,  500.00,  600.00, 700.00, 850.00,
      925.00, 1000.00,
/

&INPUT_TDEF
  INPUT_TDEF_TYPE   = 'tstep',
  INPUT_TDEF_TSTEP  = 12,
  INPUT_TDEF_DAYNUM = 4,
/

&WAVE
  WAVE_MAX_NUMBER = 0, 
/

&OUTPUT
  OUTPUT_ZONAL_FILENAME = 'output-sample/zonal200801.dr' ,
  OUTPUT_VINT_FILENAME  = 'output-sample/vint200801.dr' ,
  OUTPUT_GMEAN_FILENAME = 'output-sample/gmean200801.dr' ,
  OUTPUT_ERROR_FILENAME = 'output-sample/error200801.log' ,
/

&OUTPUT_ZDEF
  OUTPUT_ZDEF_NUM= 17,
  OUTPUT_ZDEF_LEVEL  =  
       10.00,   20.00,   30.00,  50.00,  70.00,
      100.00,  150.00,  200.00, 250.00, 300.00,
      400.00,  500.00,  600.00, 700.00, 850.00,
      925.00, 1000.00,

/


" > namelist

./MIM < namelist

